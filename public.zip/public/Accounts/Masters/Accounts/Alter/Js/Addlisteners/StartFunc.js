import { StartFunc as StartFuncSelectedColumns } from "./SelectedColumns/StartFunc.js";

let StartFunc = () => {
    StartFuncSelectedColumns();
};

export { StartFunc };