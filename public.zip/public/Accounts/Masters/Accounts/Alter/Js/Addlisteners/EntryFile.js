import { StartFunc as StartFuncSaveButtonClickId } from "./SaveButtonClickId/EntryFile.js";

const StartFunc = () => {
    StartFuncSaveButtonClickId();
};

export { StartFunc };

