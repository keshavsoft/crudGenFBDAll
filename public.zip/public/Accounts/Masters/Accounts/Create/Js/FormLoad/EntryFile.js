import { StartFunc as StartFuncForAccountNames } from "./ForDataList/AccountNames/GetFetch.js";

const StartFunc = () => {
    StartFuncForAccountNames();
};

export { StartFunc };
