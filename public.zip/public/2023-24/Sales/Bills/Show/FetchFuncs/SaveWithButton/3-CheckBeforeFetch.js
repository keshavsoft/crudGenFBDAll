let StartFunc = () => {


    return true;
};



export { StartFunc };