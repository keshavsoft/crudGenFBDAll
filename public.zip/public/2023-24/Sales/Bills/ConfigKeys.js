let KeysObject = {
    CommonKeys: {
        inFolderName: "Sales",
        inFileName: "Bills",
        inItemName: "POS"
    }
};

export {
    KeysObject
};