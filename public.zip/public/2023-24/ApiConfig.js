let ConfigObject = {
    TokenName: "KToken",
    LocalStorageKeyName: "kUserName",
    ProjectName: "JSONApi",
    CommonKeys: {
        inFolderName: "Masters",
        inFileName: "Items",
        inItemName: "ItemName"
    }
};

export {
    ConfigObject
};